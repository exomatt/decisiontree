Information about created experiment: 
Experiment id: 245
Experiment name: new one
Files used in experiment: 
- config: krotki.xml,
- data: chess3x3x10000, 
- test: chess3x3x10000(10), 
- names: chess3x3x10000(1)
