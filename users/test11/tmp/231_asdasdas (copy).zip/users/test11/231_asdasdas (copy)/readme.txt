Information about created experiment: 
Experiment id: 230
Experiment name: asdasdas
Files used in experiment: 
- config: a1.xml,
- data: test, 
- test: chess3x3x10000(4), 
- names: chess3x3x10000(1)
