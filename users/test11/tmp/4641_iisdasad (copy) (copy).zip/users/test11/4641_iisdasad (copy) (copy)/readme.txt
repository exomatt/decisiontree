Information about created experiment: 
Experiment id: 4641
Experiment name: iisdasad (copy) (copy)
Files used in experiment: 
- config: asd.xml,
- data: chess3x3x10000.data, 
- test: chess3x3x10000(10).test, 
- names: chess3x3x10000(4).names
